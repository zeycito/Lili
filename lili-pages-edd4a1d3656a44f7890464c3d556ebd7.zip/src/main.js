(function () {
  const config = window.LILI_EXPERIENCE_CONFIG;
  const memories = window.LILI_EXPERIENCE_MEMORIES || [];
  const messages = window.LILI_EXPERIENCE_MESSAGES || {};
  const root = document.getElementById("app");
  const storageKey = "lili-monster-high-secrets";
  const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  const state = {
    scene: 0,
    foundSecrets: new Set(readSecrets()),
    audio: null,
    audioReady: Boolean(config.assets.audioSrc),
    audioPlaying: false,
    volume: config.music.defaultVolume,
    yesUnlocked: false,
    noGone: false,
    noStage: "idle",
    messageRevealed: false,
  };

  let timers = [];

  const scenes = [
    { id: "intro", title: "Invitación", render: renderIntro },
    { id: "letter", title: "Carta", render: renderLetter },
    { id: "entrance", title: "Entrada", render: renderEntrance },
    { id: "student", title: "Expediente", render: renderStudentFile },
    { id: "memories", title: "Historia", render: renderMemories },
    { id: "love", title: "Detalles", render: renderThingsILove },
    { id: "eggs", title: "Secretos", render: renderEasterEggs },
    { id: "message", title: "Mensaje", render: renderPersonalMessage, after: startTypewriter },
    { id: "last-stop", title: "Última parada", render: renderLastStop },
    { id: "proposal", title: "Pregunta", render: renderProposal, after: maybeRunNoEscape },
    { id: "celebration", title: "Final", render: renderCelebration },
    { id: "epilogue", title: "Epílogo", render: renderEpilogue },
  ];

  initAudio();
  root.addEventListener("click", handleClick);
  root.addEventListener("input", handleInput);
  render();

  function initAudio() {
    if (!state.audioReady) return;
    state.audio = new Audio(config.assets.audioSrc);
    state.audio.loop = true;
    state.audio.volume = state.volume;
  }

  function handleClick(event) {
    const secret = event.target.closest("[data-secret]");
    if (secret) {
      collectSecret(secret.dataset.secret);
      return;
    }

    const actionTarget = event.target.closest("[data-action]");
    if (!actionTarget) return;

    const action = actionTarget.dataset.action;
    if (action === "open-letter") openLetter(actionTarget);
    if (action === "next") goTo(state.scene + 1);
    if (action === "restart") restartExperience();
    if (action === "toggle-music") toggleMusic();
    if (action === "reveal-message") revealPersonalMessage();
    if (action === "try-yes") tryYes();
    if (action === "press-no") startNoEscape();
    if (action === "accept-yes") goTo(10);
  }

  function handleInput(event) {
    const input = event.target.closest("[data-action='set-volume']");
    if (!input) return;
    state.volume = Number(input.value);
    if (state.audio) state.audio.volume = state.volume;
    updateMusicControl();
  }

  function openLetter(button) {
    button.classList.add("is-opening");
    playMusic();
    queue(() => goTo(1), reducedMotion ? 120 : 760);
  }

  function goTo(nextScene) {
    state.scene = Math.max(0, Math.min(nextScene, scenes.length - 1));
    render();
  }

  function restartExperience() {
    state.scene = 0;
    state.yesUnlocked = false;
    state.noGone = false;
    state.noStage = "idle";
    render();
  }

  function tryYes() {
    if (!state.yesUnlocked) {
      showToast("Espera... todavía no.");
      const yesButton = root.querySelector(".proposal-yes");
      yesButton?.classList.add("is-denied");
      queue(() => yesButton?.classList.remove("is-denied"), 550);
      return;
    }
    goTo(10);
  }

  function startNoEscape() {
    if (state.noGone || state.noStage === "running") return;
    state.noStage = "running";
    render();
  }

  function maybeRunNoEscape() {
    if (state.noStage !== "running" || state.noGone) return;
    const creature = root.querySelector(".no-creature");
    const stage = root.querySelector(".proposal-stage");
    if (!creature || !stage) return;

    const phrases = [
      "¡Hey! No tan fácil.",
      "Casi me atrapas.",
      "Ese botón tenía otros planes.",
      "Jajajaja.",
    ];

    const steps = reducedMotion ? 3 : 7;
    const duration = reducedMotion ? 450 : Math.max(460, config.timings.noEscapeMs / steps);

    for (let step = 0; step < steps; step += 1) {
      queue(() => {
        const bounds = stage.getBoundingClientRect();
        const buttonBounds = creature.getBoundingClientRect();
        const maxX = Math.max(0, bounds.width - buttonBounds.width - 24);
        const maxY = Math.max(0, bounds.height - buttonBounds.height - 24);
        const x = 12 + Math.round(pseudoRandom(step + 1) * maxX);
        const y = 12 + Math.round(pseudoRandom(step + 7) * maxY);
        creature.style.left = `${x}px`;
        creature.style.top = `${y}px`;
        creature.style.transform = `rotate(${step % 2 ? -7 : 9}deg)`;
        creature.dataset.bubble = phrases[step % phrases.length];
      }, 120 + step * duration);
    }

    queue(() => {
      creature.classList.add("is-vanishing");
      showToast("Parece que ese botón se escapó.");
    }, 240 + steps * duration);

    queue(() => {
      state.noGone = true;
      state.yesUnlocked = true;
      state.noStage = "gone";
      render();
      showToast("Ahora sí puedes tocar SÍ.");
    }, 980 + steps * duration);
  }

  function render() {
    clearTimers();
    const scene = scenes[state.scene];
    root.innerHTML = `
      <main class="experience scene-${scene.id}">
        ${renderAmbient()}
        ${renderProgress()}
        ${renderMusicControl()}
        ${renderSecretLayer()}
        <section class="scene-panel" aria-label="${attr(scene.title)}">
          ${scene.render()}
        </section>
        <div class="toast" id="toast" role="status" aria-live="polite"></div>
      </main>
    `;
    scene.after?.();
  }

  function renderIntro() {
    return `
      <div class="intro-layout">
        <div class="logo-stack" aria-label="Monster High">
          <img class="brand-logo brand-crest" src="${attr(config.assets.logo)}" alt="Escudo de Monster High" />
          <img class="brand-logo brand-wordmark" src="${attr(config.assets.wordmark)}" alt="Monster High" />
        </div>
        <p class="scene-kicker">Lili, tienes una invitación especial...</p>
        <button class="envelope-button" type="button" data-action="open-letter" aria-label="Abrir la carta especial">
          <span class="envelope">
            <span class="envelope-flap"></span>
            <span class="envelope-seal">❤</span>
          </span>
          <span class="button-copy">Haz clic para abrirla</span>
        </button>
      </div>
    `;
  }

  function renderLetter() {
    return `
      <div class="letter-layout">
        <article class="paper letter-paper">
          <span class="paper-pin">❤</span>
          ${config.letter.map((line) => `<p>${text(line)}</p>`).join("")}
          <p class="signature">${text(config.people.sender)}</p>
        </article>
        <button class="primary-action" type="button" data-action="next">Continuar <span aria-hidden="true">→</span></button>
      </div>
    `;
  }

  function renderEntrance() {
    return `
      <div class="entrance-layout">
        <div class="moon" aria-hidden="true"></div>
        <img class="castle-art" src="${attr(config.assets.castle)}" alt="Entrada reemplazable a Monster High" />
        <div class="fog" aria-hidden="true"></div>
        <div class="scene-copy">
          <p class="scene-kicker">La carta se abre y el pasillo aparece...</p>
          <h1 id="scene-title">Bienvenida a Monster High, ${text(config.people.recipient)}.</h1>
        </div>
        <button class="primary-action" type="button" data-action="next">Comenzar recorrido <span aria-hidden="true">→</span></button>
      </div>
    `;
  }

  function renderStudentFile() {
    const file = config.studentFile;
    const rows = [
      ["Nombre", file.name],
      ["Especie", file.species],
      ["Edad", file.age],
      ["Debilidad", file.weakness],
      ["Poder especial", file.power],
      ["Compañero", file.companion],
      ["Estado sentimental", file.relationshipStatus],
    ];

    return `
      <div class="student-layout">
        <article class="student-file">
          <div class="file-heading">
            <img src="${attr(config.assets.logo)}" alt="" aria-hidden="true" />
            <div>
              <p class="scene-kicker">Monster High</p>
              <h1 id="scene-title">Student File</h1>
            </div>
          </div>
          <div class="file-body">
            <div class="file-fields">
              ${rows
                .map(
                  ([label, value]) => `
                  <p><strong>${text(label)}:</strong> <span>${text(value)}</span></p>
                `,
                )
                .join("")}
            </div>
            <figure class="profile-photo">
              <img src="${attr(config.assets.liliPhoto)}" alt="Fotografía reemplazable de Lili" loading="lazy" />
              <figcaption>Foto de ${text(config.people.recipient)}</figcaption>
            </figure>
          </div>
        </article>
        <img class="clawdeen-art" src="${attr(config.assets.clawdeen)}" alt="Ilustración decorativa reemplazable inspirada en Clawdeen" loading="lazy" />
        <button class="primary-action" type="button" data-action="next">Siguiente <span aria-hidden="true">→</span></button>
      </div>
    `;
  }

  function renderMemories() {
    return `
      <div class="scrapbook-layout">
        <div class="scene-copy">
          <p class="scene-kicker">Yearbook secreto</p>
          <h1 id="scene-title">Nuestra historia</h1>
        </div>
        <div class="memory-grid">
          ${memories
            .map(
              (memory, index) => `
              <article class="memory-card rotate-${(index % 3) + 1}">
                <span class="photo-tape" aria-hidden="true"></span>
                <img src="${attr(memory.image)}" alt="${attr(memory.title)}" loading="lazy" />
                <div>
                  <p class="memory-date">${text(memory.date)}</p>
                  <h2>${text(memory.title)}</h2>
                  <p>${text(memory.description)}</p>
                </div>
              </article>
            `,
            )
            .join("")}
        </div>
        <button class="primary-action" type="button" data-action="next">Continuar <span aria-hidden="true">→</span></button>
      </div>
    `;
  }

  function renderThingsILove() {
    return `
      <div class="love-layout">
        <img class="sunflower-corner" src="${attr(config.assets.sunflower)}" alt="" aria-hidden="true" loading="lazy" />
        <div class="scene-copy">
          <p class="scene-kicker">Pequeñas razones</p>
          <h1 id="scene-title">Cosas que amo de ti</h1>
        </div>
        <div class="love-notes">
          ${(messages.thingsILove || [])
            .map(
              (item, index) => `
              <article class="love-note note-${index + 1}">
                <span aria-hidden="true">❤</span>
                <p>${text(item)}</p>
              </article>
            `,
            )
            .join("")}
        </div>
        <button class="primary-action" type="button" data-action="next">Siguiente <span aria-hidden="true">→</span></button>
      </div>
    `;
  }

  function renderEasterEggs() {
    const eggs = messages.easterEggs || [];
    return `
      <div class="eggs-layout">
        <div class="scene-copy">
          <p class="scene-kicker">Secretos opcionales</p>
          <h1 id="scene-title">Easter eggs interactivos</h1>
          <p>Toca los símbolos escondidos durante el recorrido. No detienen la historia; solo guardan recuerdos extra.</p>
        </div>
        <div class="egg-grid">
          ${eggs
            .map(
              (egg) => `
              <button class="egg-card ${state.foundSecrets.has(egg.id) ? "is-found" : ""}" type="button" data-secret="${attr(egg.id)}">
                <span class="egg-icon" aria-hidden="true">${egg.icon}</span>
                <span>${text(egg.label)}</span>
              </button>
            `,
            )
            .join("")}
        </div>
        <div class="secret-reveal">
          ${eggs
            .filter((egg) => state.foundSecrets.has(egg.id))
            .map(
              (egg) => `
              <article class="secret-card">
                <img src="${attr(egg.image)}" alt="${attr(egg.title)}" loading="lazy" />
                <div>
                  <h2>${text(egg.title)}</h2>
                  <p>${text(egg.note)}</p>
                </div>
              </article>
            `,
            )
            .join("") || `<p class="muted">Todavía hay secretos esperando a ser tocados.</p>`}
        </div>
        <button class="primary-action" type="button" data-action="next">Continuar <span aria-hidden="true">→</span></button>
      </div>
    `;
  }

  function renderPersonalMessage() {
    return `
      <div class="message-layout">
        <div class="photo-orbit" aria-hidden="true">
          <img src="${attr(config.assets.couplePhoto)}" alt="" loading="lazy" />
          <img src="${attr(config.assets.liliPhoto)}" alt="" loading="lazy" />
        </div>
        <article class="paper intimate-letter">
          <p class="scene-kicker">Lo que siento por ti</p>
          <h1 id="scene-title">Para ${text(config.people.recipient)}</h1>
          <div class="typewriter" data-typewriter aria-live="polite"></div>
          <button class="letter-reveal" type="button" data-action="reveal-message">Leer la carta completa</button>
        </article>
        <button class="primary-action" type="button" data-action="next">Siguiente <span aria-hidden="true">→</span></button>
      </div>
    `;
  }

  function renderLastStop() {
    return `
      <div class="last-stop-layout">
        <div class="sunflower-field" aria-hidden="true">
          ${Array.from({ length: 24 }, (_, index) => `<span style="--i:${index}"></span>`).join("")}
        </div>
        <figure class="bench-photo">
          <img src="${attr(config.assets.couplePhoto)}" alt="Fotografía reemplazable de ustedes dos" loading="lazy" />
        </figure>
        <div class="scene-copy">
          <p class="scene-kicker">Un momento especial antes de la gran pregunta...</p>
          <h1 id="scene-title">${text(config.people.recipient)}...</h1>
          <p>Después de todo este recorrido hay algo que quiero preguntarte.</p>
        </div>
        <button class="primary-action" type="button" data-action="next">Continuar <span aria-hidden="true">→</span></button>
      </div>
    `;
  }

  function renderProposal() {
    const yesLabel = state.yesUnlocked ? "🔓 SÍ" : "🔒 SÍ";
    return `
      <div class="proposal-layout">
        <div class="proposal-stage">
          <div class="question-copy">
            <p class="scene-kicker">${text(config.people.recipient)}...</p>
            <p>Hay muchas cosas que podría decirte aquí.</p>
            <p>Pero creo que hay una pregunta que resume perfectamente lo que quiero.</p>
            <h1 id="scene-title">${text(config.finalQuestion)}</h1>
          </div>
          <div class="proposal-actions">
            <button
              class="proposal-yes ${state.yesUnlocked ? "is-unlocked" : "is-locked"}"
              type="button"
              data-action="${state.yesUnlocked ? "accept-yes" : "try-yes"}"
              aria-label="${state.yesUnlocked ? "SÍ desbloqueado" : "SÍ bloqueado. Espera todavía no."}"
            >
              ${yesLabel}
            </button>
            ${
              state.noGone
                ? `<p class="no-gone">El NO desapareció. Solo queda el SÍ.</p>`
                : `
                  <button class="proposal-no no-creature" type="button" data-action="press-no" data-bubble="Tócame si puedes" aria-label="NO">
                    <span class="spider-portal">
                      <img src="${attr(config.assets.spider)}" alt="" aria-hidden="true" />
                      <span class="spider-no-label">NO</span>
                    </span>
                  </button>
                `
            }
          </div>
        </div>
      </div>
    `;
  }

  function renderCelebration() {
    return `
      <div class="celebration-layout">
        <div class="celebration-burst" aria-hidden="true">
          ${Array.from({ length: 34 }, (_, index) => `<span style="--i:${index}"></span>`).join("")}
        </div>
        <div class="photo-final">
          <img src="${attr(config.assets.couplePhoto)}" alt="Fotografía final reemplazable de Lili y Mario" loading="lazy" />
        </div>
        <div class="scene-copy">
          <p class="mega-yes">¡¡¡SÍ!!!</p>
          <p>Entonces ya podemos decirlo oficialmente.</p>
          <h1 id="scene-title">${text(config.people.coupleLabel)}</h1>
          <p class="novios">NOVIOS ❤</p>
        </div>
        <button class="primary-action" type="button" data-action="next">Ver epílogo <span aria-hidden="true">→</span></button>
      </div>
    `;
  }

  function renderEpilogue() {
    return `
      <div class="epilogue-layout">
        <article class="paper epilogue-paper">
          <p>Esto no es el comienzo de nuestra historia.</p>
          <p>Es el momento en que decidimos hacerla oficial.</p>
          <p>Gracias por recorrer todo esto conmigo.</p>
          <span class="paper-heart" aria-hidden="true">❤</span>
        </article>
        <button class="primary-action" type="button" data-action="restart">Volver a vivir nuestra historia</button>
      </div>
    `;
  }

  function renderAmbient() {
    return `
      <div class="ambient" aria-hidden="true">
        <span class="bat bat-1">⌁</span>
        <span class="bat bat-2">⌁</span>
        <span class="heart heart-1">❤</span>
        <span class="heart heart-2">❤</span>
        <span class="spark spark-1">✦</span>
        <span class="spark spark-2">✧</span>
        <span class="web web-1"></span>
        <span class="web web-2"></span>
      </div>
    `;
  }

  function renderProgress() {
    return `
      <nav class="story-progress" aria-label="Progreso del recorrido">
        ${scenes
          .map(
            (scene, index) => `
            <span class="progress-charm ${index <= state.scene ? "is-lit" : ""}" aria-label="${text(scene.title)}"></span>
          `,
          )
          .join("")}
      </nav>
    `;
  }

  function renderMusicControl() {
    const status = state.audioReady ? config.music.title : "Agrega el audio";
    const icon = state.audioPlaying ? "⏸" : "▶";
    return `
      <div class="music-control" data-music-control>
        <button
          type="button"
          data-action="toggle-music"
          ${state.audioReady ? "" : "disabled"}
          aria-label="${state.audioPlaying ? "Pausar música" : "Reproducir música"}"
        >${icon}</button>
        <span>${text(status)}</span>
        <label>
          <span class="sr-only">Volumen</span>
          <input
            type="range"
            min="0"
            max="1"
            step="0.05"
            value="${state.volume}"
            data-action="set-volume"
            ${state.audioReady ? "" : "disabled"}
          />
        </label>
      </div>
    `;
  }

  function renderSecretLayer() {
    if (state.scene === 0 || state.scene >= 9) return "";
    const eggs = messages.easterEggs || [];
    const positions = [
      ["8%", "72%"],
      ["86%", "22%"],
      ["76%", "77%"],
    ];
    return `
      <div class="secret-layer" aria-label="Secretos escondidos">
        ${eggs
          .slice(0, 3)
          .map((egg, index) => {
            const [left, top] = positions[(index + state.scene) % positions.length];
            return `
              <button
                class="secret-dot ${state.foundSecrets.has(egg.id) ? "is-found" : ""}"
                type="button"
                data-secret="${attr(egg.id)}"
                style="--x:${left}; --y:${top}"
                aria-label="Secreto: ${attr(egg.label)}"
              >${egg.icon}</button>
            `;
          })
          .join("")}
      </div>
    `;
  }

  function startTypewriter() {
    const container = root.querySelector("[data-typewriter]");
    if (!container) return;
    const fullText = (messages.personalMessage || []).join("\n\n");
    if (reducedMotion || state.messageRevealed) {
      fillPersonalMessage(container, fullText);
      return;
    }

    const charDelay = Math.min(config.timings.typewriterSpeedMs, 9);
    let index = 0;
    const write = () => {
      index += 1;
      const current = fullText.slice(0, index);
      fillPersonalMessage(container, current);
      if (index < fullText.length && !state.messageRevealed) queue(write, charDelay);
    };
    write();
  }

  function fillPersonalMessage(container, value) {
    container.innerHTML = value
      .split("\n\n")
      .map((paragraph) => `<p>${text(paragraph)}</p>`)
      .join("");
  }

  function revealPersonalMessage() {
    const container = root.querySelector("[data-typewriter]");
    if (!container) return;
    state.messageRevealed = true;
    clearTimers();
    fillPersonalMessage(container, (messages.personalMessage || []).join("\n\n"));
    const control = root.querySelector("[data-action='reveal-message']");
    if (control) control.remove();
  }

  function collectSecret(id) {
    const egg = (messages.easterEggs || []).find((item) => item.id === id);
    if (!egg) return;
    state.foundSecrets.add(id);
    localStorage.setItem(storageKey, JSON.stringify(Array.from(state.foundSecrets)));
    showToast(egg.title);
    const existingCard = root.querySelector(`.egg-card[data-secret="${CSS.escape(id)}"]`);
    existingCard?.classList.add("is-found");
    const existingDot = root.querySelector(`.secret-dot[data-secret="${CSS.escape(id)}"]`);
    existingDot?.classList.add("is-found");
  }

  function playMusic() {
    if (!state.audioReady || !state.audio) return;
    state.audio
      .play()
      .then(() => {
        state.audioPlaying = true;
        updateMusicControl();
      })
      .catch(() => {
        showToast("Toca el control de música para activarla.");
      });
  }

  function toggleMusic() {
    if (!state.audioReady || !state.audio) return;
    if (state.audio.paused) {
      playMusic();
    } else {
      state.audio.pause();
      state.audioPlaying = false;
      updateMusicControl();
    }
  }

  function updateMusicControl() {
    const control = root.querySelector("[data-music-control]");
    if (!control) return;
    control.outerHTML = renderMusicControl();
  }

  function showToast(message) {
    const toast = root.querySelector("#toast");
    if (!toast) return;
    toast.textContent = message;
    toast.classList.add("is-visible");
    queue(() => toast.classList.remove("is-visible"), 2600);
  }

  function readSecrets() {
    try {
      return JSON.parse(localStorage.getItem(storageKey) || "[]");
    } catch {
      return [];
    }
  }

  function queue(callback, delay) {
    const id = window.setTimeout(callback, delay);
    timers.push(id);
    return id;
  }

  function clearTimers() {
    timers.forEach((id) => window.clearTimeout(id));
    timers = [];
  }

  function pseudoRandom(seed) {
    const value = Math.sin(seed * 999 + state.scene * 31) * 10000;
    return value - Math.floor(value);
  }

  function text(value) {
    return String(value ?? "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;");
  }

  function attr(value) {
    return text(value).replace(/"/g, "&quot;");
  }
})();
