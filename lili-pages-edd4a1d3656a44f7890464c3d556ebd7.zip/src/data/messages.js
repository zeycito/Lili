window.LILI_EXPERIENCE_MESSAGES = {
  thingsILove: [
    "Tu forma de hacer que cualquier momento se sienta mas bonito.",
    "Los detalles pequeños que tal vez no notas, pero yo si guardo.",
    "La manera en que estar contigo se siente como casa.",
    "Tus risas, tus gestos y esa energia que ilumina todo.",
  ],
  personalMessage: [
    "No sé en qué momento comenzaste a convertirte en una de mis partes favoritas de la vida. Quizá fue entre tus sonrisas, en esas conversaciones que parecen no tener final, o en esos pequeños momentos en los que, sin hacer absolutamente nada extraordinario, consigues que todo se sienta un poquito mejor.",
    "Lo que siento por ti no cabe en un simple «te quiero». Porque quererte es también encontrar belleza en tus días buenos, querer acompañarte en los difíciles y descubrir que hasta los momentos más sencillos tienen algo especial cuando los comparto contigo.",
    "Me gusta tu manera de existir, tus ocurrencias, tu forma de mirar el mundo y hasta esos pequeños detalles que probablemente tú no notas, pero que yo he aprendido a guardar con muchísimo cariño.",
    "No quiero prometerte una vida perfecta, porque sé que no existe. Quiero prometerte algo mucho más humano: mis ganas de construir contigo, de aprender a quererte cada día mejor, de tomarte de la mano cuando el camino sea complicado y de seguir eligiéndote incluso en esos días en los que la vida no sea tan bonita.",
    "Porque si algo he descubierto contigo es que el amor no siempre llega haciendo ruido. A veces llega despacito, se sienta a tu lado, te hace reír por cualquier tontería y, cuando menos te das cuenta, ya no imaginas tus días sin esa persona.",
    "Y si algún día me preguntan qué es lo que más me gusta de la vida, probablemente no encuentre las palabras adecuadas para explicarlo. Pero pensaré en ti.",
    "Porque entre tantas personas, tantos lugares y tantas posibilidades, qué bonito ha sido coincidir contigo. Y qué bonito es que, de todas las historias que todavía me quedan por vivir, una de las que más ilusión me hace escribir sea contigo.",
  ],
  easterEggs: [
    {
      id: "web",
      icon: "🕸",
      label: "Telaraña",
      title: "Encontraste un secreto.",
      note: "Un pequeño momento juntos, guardado entre los hilos de esta historia.",
      image: "./assets/photos/couple-close.jpg",
    },
    {
      id: "heart",
      icon: "❤",
      label: "Corazón",
      title: "Un latido guardado.",
      note: "Las fotos se ven bonitas, pero contigo hasta el silencio se siente especial.",
      image: "./assets/photos/couple-red.jpg",
    },
    {
      id: "sunflower",
      icon: "🌻",
      label: "Girasol",
      title: "Una pista con luz.",
      note: "Un secreto para recordarte que contigo siempre encuentro color.",
      image: "./assets/photos/lili-closeup.jpg",
    },
  ],
};
