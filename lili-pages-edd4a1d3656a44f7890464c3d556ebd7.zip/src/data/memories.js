window.LILI_EXPERIENCE_MEMORIES = [
  {
    image: "./assets/photos/couple-portrait.jpg",
    date: "NOSOTROS",
    title: "Una foto que se siente muy nuestra",
    description: "Porque las mejores historias también se guardan en abrazos apretados.",
  },
  {
    image: "./assets/photos/couple-night-hug.jpg",
    date: "NOCHE",
    title: "Contigo, hasta una noche normal se vuelve especial",
    description: "Una de esas fotos que guarda más cariño del que cabe en una pantalla.",
  },
  {
    image: "./assets/photos/couple-sunglasses.jpg",
    date: "ATRAE EL SOL",
    title: "Dos personas cool en la misma foto",
    description: "La prueba oficial de que el estilo se ve mejor cuando se comparte.",
  },
  {
    image: "./assets/photos/scrapbook-memory.jpg",
    date: "SCRAPBOOK",
    title: "Un recuerdo que ya venía enmarcado",
    description: "Una página de nosotros, hecha para quedarse.",
  },
  {
    image: "./assets/photos/couple-mirror.jpg",
    date: "ESPEJO",
    title: "Mi lugar favorito está cerca de ti",
    description: "Da igual dónde estemos: contigo la escena siempre mejora.",
  },
  {
    image: "./assets/photos/couple-home.jpg",
    date: "COMPLICIDAD",
    title: "Las risas también son recuerdos",
    description: "La parte de nosotros que no necesita explicación.",
  },
];
